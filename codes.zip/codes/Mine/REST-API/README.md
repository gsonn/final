# REST-API
Implemented rest api's for selfielessacts application using python flask.
