from flask import Flask, jsonify,abort
import  csv
import time
import hashlib
import re
from flask import make_response
import datetime
from flask import request
import requests
import sys
import subprocess
from sets import Set

app=Flask(__name__)

@app.route('/api/v1/requests',methods=['GET','POST','DELETE'])
def forword_request():
    container1 = request.get("http://container1link")
    container2=request.get("http://container2link")
    container3=request.get("http://container3linl")


    print(container1.status_code)
    print(container2.status_code)
    print(container3.status_code)
    c1=container1.json()
    c2=container2.json()
    c4=container3.json()
    print(c1)
    print(c2)
    print(c3)

def fault_tolerant():


if __name__=='__main__':
    app.run(host='127.0.0.1',port=80)
