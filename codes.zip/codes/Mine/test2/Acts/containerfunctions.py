import docker
client = docker.from_env()

act_ports=[8000,8001,8002]

#To launch container
def launch_container(port):
    container = client.containers.run("gshankar0/acts-final:latest", ports={'80':str(port)})
    print(container.id)
    return  container.id


'''
#To stop all containers
def stop_all_containers():
    for container in client.containers.list():
        container.stop()

#To stop any perticular container
def stop_single_container(containerId):
    containerId.stop()


#To print logs of specific container
def print_logs_specific(containerId):
    container=client.containers.get(containerId)
    print=container.logs()

#Listing all running images
for image in client.images.list():
    return image.id
'''
