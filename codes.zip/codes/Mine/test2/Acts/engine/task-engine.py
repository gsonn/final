from flask import Flask, jsonify,abort
import  csv
import time
import hashlib
import re
from flask import make_response
import datetime
from flask import request
import requests
import sys
import subprocess
from sets import Set
app=Flask(__name__)
count = 0
l=[8000,8001,8002]
@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error':'not found'}),404)
count = count + 1


#Health Check
@app.route('/api/v1/_health',methods=['GET'])
def check_server_health():
    i=(count+1)%len((l))
    count = count + 1
    r= requests.get('http://localhost:'+str(l[i])+'/api/v1/_health')
    d=r.json()
    return jsonify(d),r.status_code







# return total number of request
@app.route('/api/v1/_count',methods=['GET'])
def total_request():
    i=(count+1)%len((l))
    count = count + 1
    r= requests.get('http://localhost:'+str(l[i])+'/api/v1/_count')
    d=r.json()
    return jsonify(d),r.status_code



# get total number of acts
@app.route('/api/v1/acts/count',methods=['GET'])
def total_countsof_acts():
    i=(count+1)%len((l))
    count = count + 1
    r= requests.get('http://localhost:'+str(l[i])+'/api/v1/count')
    d=r.json()
    return jsonify(d),r.status_code






#1 list all categories
@app.route('/api/v1/categories',methods=['GET'])
def list_cat():
    global count
    i=(count+1)%len((l))
    count=count+1
    r= requests.get('http://localhost:'+str(l[i])+'/api/v1/categories')
    d=r.json()
    return jsonify(d),r.status_code

#3 Add a category
from flask import request
@app.route('/api/v1/categories',methods=['POST'])
def add_cat():
        global count
        i=(count+1)%len((l))
        count=count+1
        r= requests.post('http://localhost:'+str(l[i])+'/api/v1/categories')
        d=r.json()
        return jsonify(d),r.status_code



#4 delete category
@app.route('/api/v1/categories/<categoryName>',methods=['DELETE'])
def delete_cat(categoryName):
    global count
    i=(count+1)%len((l))
    count=count+1
    r= requests.post('http://localhost:'+str(l[i])+'/api/v1/categories<categoryname>')
    d=r.json()
    return jsonify(d),r.status_code




#7 Add and act
@app.route('/api/v1/acts',methods=['POST'])
def add_act():
    global count
    i=(count+1)%len((l))
    count=count+1
    r= requests.post('http://localhost:'+str(l[i])+'/api/v1/acts')
    d=r.json()
    return jsonify(d),r.status_code


#8 Remove an act
@app.route('/api/v1/acts/<actId>',methods=['DELETE'])
def remove_act(actId):
    global count
    i=(count+1)%len((l))
    count=count+1
    r= requests.post('http://localhost:'+str(l[i])+'/api/v1/acts/<actId>')
    d=r.json()
    return jsonify(d),r.status_code

#9 upvote an act
@app.route('/api/v1/acts/upvote',methods=['POST'])
def upvote_act():
    global count
    i=(count+1)%len((l))
    count=count+1
    r= requests.post('http://localhost:'+str(l[i])+'/api/v1/acts/upvote')
    d=r.json()
    return jsonify(d),r.status_code



if __name__=='__main__':
    app.run(host='127.0.0.1',port=80)
