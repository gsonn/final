import docker
import subprocess
import os,sys

client = docker.from_env()


list=[8000,8001,8002]

#To launch container





def launch_container(port):
    container = client.containers.run("acts", ports={'80':str(port)},detach=True)
    return container.id

def list_container():
    list2=["docker","ps","-a","-q"]
    ss=subprocess.run(list2,stdout=subprocess.PIPE)
    id=ss.stdout.decode()
    #f=open('file.txt','w')
    #print(id)
    #f.write(id)
    #print(id)
    #return ss
    stop_single_container()
    #print(type(ss))
    return id


#To stop all containers
def stop_all_containers():
    for container in client.containers.list():
        container.stop()

def stop_single_container():
    subprocess.call('docker stop $(docker ps -a -q)[0]',shell=True)

#
#a=list_container()
f=open('file.csv','w')
#sys.stdout=f
#print()
#stop_all_containers()
#stop_single_container(a)


#print(type(a))


#stop_single_container(a)
'''
#To stop any perticular container



#To print logs of specific container
def print_logs_specific(containerId):
    container=client.containers.get(containerId)
    print=container.logs()

Listing all running images

'''
